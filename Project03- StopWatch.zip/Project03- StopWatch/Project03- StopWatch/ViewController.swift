//
//  ViewController.swift
//  Project03- StopWatch
//
//  Created by BinaryVentures_Sadid on 3/21/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit

class ViewController: UIViewController , UITableViewDelegate, UITableViewDataSource{
// MARK: - UI components
    @IBOutlet var lapTimerLabel: UILabel!
    @IBOutlet var timerLabel: UILabel!
    
    @IBOutlet var lapResetButton: UIButton!
    
    @IBOutlet var startStopButton: UIButton!
    @IBOutlet var lapTableView: UITableView!
    
    
    // MARK: Variables
    fileprivate let mainWatch: StopWatch = StopWatch()
    
    fileprivate let lapStopWatch: StopWatch = StopWatch()
    
    fileprivate var isPlay : Bool = false
    fileprivate var laps : [String] = []
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
        
        // make the button in round shape
        
        let initCircleButton:(UIButton) -> Void = {
            button in
            button.layer.cornerRadius =  button.bounds.size.height / 2.0
            button.clipsToBounds = true
            
           // button.layer.cornerRadius = 0.8 * button.bounds.size.width
           // button.backgroundColor = UIColor.white
            
        }
        
        initCircleButton(startStopButton)
        initCircleButton(lapResetButton)
        
        lapResetButton.isEnabled = false
        
        lapTableView.delegate = self
        lapTableView.dataSource = self
        
        
        
    }
// MARK: - UI Settings
    override var shouldAutorotate: Bool{
        return false
    }
    
    override var preferredStatusBarStyle: UIStatusBarStyle{
        return UIStatusBarStyle.lightContent
    }
    
    override var supportedInterfaceOrientations: UIInterfaceOrientationMask{
        return UIInterfaceOrientationMask.portrait
    }
    
    // mark button Action

    @IBAction func startStopButtonClicked(_ sender: Any) {
        lapResetButton.isEnabled = true
        changeButton(lapResetButton, title: "Lap", titleColor: UIColor.black)
        
        if !isPlay {
            unowned let weakSelf = self
            
            mainWatch.timer = Timer.scheduledTimer(timeInterval: 0.035, target: weakSelf, selector: Selector.updateMainTimer, userInfo: nil, repeats: true)
            lapStopWatch.timer = Timer.scheduledTimer(timeInterval: 0.035, target: weakSelf, selector: Selector.updateLapTimer, userInfo: nil, repeats: true)
            
            RunLoop.current.add(mainWatch.timer, forMode: .commonModes)
            RunLoop.current.add(lapStopWatch.timer, forMode: .commonModes)
            
            isPlay = true
            changeButton(startStopButton, title: "Stop", titleColor: UIColor.red)
        } else {
            
            mainWatch.timer.invalidate()
            lapStopWatch.timer.invalidate()
            isPlay = false
            changeButton(startStopButton, title: "Start", titleColor: UIColor.green)
            changeButton(lapResetButton, title: "Reset", titleColor: UIColor.black)
        }
        
        
        
    }
    @IBAction func lapResetButtonClicked(_ sender: Any) {
        
        if !isPlay {
            resetMainTimer()
            resetLapTimer()
            changeButton(lapResetButton, title: "Lap", titleColor: UIColor.lightGray)
            lapResetButton.isEnabled = false
        } else {
            if let timerLabelText = timerLabel.text {
                laps.append(timerLabelText)
            }
            lapTableView.reloadData()
            resetLapTimer()
            unowned let weakSelf = self
            lapStopWatch.timer = Timer.scheduledTimer(timeInterval: 0.035, target: weakSelf, selector: Selector.updateLapTimer, userInfo: nil, repeats: true)
            RunLoop.current.add(lapStopWatch.timer, forMode: .commonModes)
        }
    }
    
     // MARK: - Private Helpers
    fileprivate func changeButton(_ button: UIButton, title : String, titleColor: UIColor){
        button.setTitle(title, for: UIControlState())
        button.setTitleColor(titleColor, for: UIControlState())
        
    }
    
    fileprivate func resetMainTimer(){
        resetTimer(mainWatch, label: timerLabel)
        laps.removeAll()
        lapTableView.reloadData()
    }
    
    fileprivate func resetTimer(_ stopwatch: StopWatch , label : UILabel){
        // timer reset
        stopwatch.timer.invalidate()
        stopwatch.counter = 0.0
        label.text = "00:00:00"
    }
    
    fileprivate func resetLapTimer(){
        resetTimer(lapStopWatch, label: lapTimerLabel)
    }
    
    @objc func updateMainTimer() {
        updateTimer(mainWatch, label: timerLabel)
    }
    
    @objc func updateLapTimer() {
        updateTimer(lapStopWatch, label: lapTimerLabel)
    }
    
    func updateTimer(_ stopwatch: StopWatch, label: UILabel) {
        stopwatch.counter = stopwatch.counter + 0.035
        
        var minutes: String = "\((Int)(stopwatch.counter / 60))"
        if (Int)(stopwatch.counter / 60) < 10 {
            minutes = "0\((Int)(stopwatch.counter / 60))"
        }
        
        var seconds: String = String(format: "%.2f", (stopwatch.counter.truncatingRemainder(dividingBy: 60)))
        if stopwatch.counter.truncatingRemainder(dividingBy: 60) < 10 {
            seconds = "0" + seconds
        }
        
        label.text = minutes + ":" + seconds
    }

    
  
    
    
    
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
        return laps.count
    }
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
        let cell =  tableView.dequeueReusableCell(withIdentifier: "lapCell", for: indexPath) as! lapCell
        
        
        cell.lapNumber.text = "Lap \(indexPath.row + 1)"
        print(indexPath.row)
        
    
       
        cell.lapTimer.text = laps[indexPath.row]
       
       
    return cell
    }

    func tableView(_ tableView: UITableView, heightForRowAt indexPath: IndexPath) -> CGFloat {
        return 100.0
    }

}

// MARK: - Extension
fileprivate extension Selector {
    static let updateMainTimer = #selector(ViewController.updateMainTimer)
    static let updateLapTimer = #selector(ViewController.updateLapTimer)
}

