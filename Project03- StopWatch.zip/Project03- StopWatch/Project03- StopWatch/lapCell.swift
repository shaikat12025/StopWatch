//
//  lapCell.swift
//  Project03- StopWatch
//
//  Created by BinaryVentures_Sadid on 3/22/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import UIKit

class lapCell: UITableViewCell {

    
    @IBOutlet var lapNumber: UILabel!
    
    @IBOutlet var lapTimer: UILabel!
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
