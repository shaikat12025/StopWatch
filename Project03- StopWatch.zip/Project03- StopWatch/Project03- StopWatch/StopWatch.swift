//
//  StopWatch.swift
//  Project03- StopWatch
//
//  Created by BinaryVentures_Sadid on 3/21/18.
//  Copyright © 2018 BinaryVentures_Sadid. All rights reserved.
//

import Foundation

class StopWatch : NSObject{
    var counter : Double
    var timer : Timer
    
    override init() {
        counter = 0.0
        timer = Timer()
    }
}
